./hpcArrayRun.sh noMinCO2 100 scenarioE-resTarget.xml
./hpcArrayRun.sh MinCO2 100 scenarioE-MinCO2-resTarget.xml
./hpcArrayRun.sh lowRes 100 scenarioE-lowResTarget.xml
./hpcArrayRun.sh highRes 100 scenarioE-highResTarget.xml
./hpcArrayRun.sh highMinCO2 100 scenarioE-highMinCO2-resTarget.xml
./hpcArrayRun.sh nlMinCO2 100 scenarioE-nlMinCO2-resTarget.xml
./hpcArrayRun.sh noRes 100 scenarioE-noResTarget.xml