#!/bin/bash
rm -rf /var/tmp/* /tmp/*
